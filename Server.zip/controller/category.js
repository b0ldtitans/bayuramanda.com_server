const { where } = require("sequelize");
const { Category } = require("../models");
const { sequelize } = require("../models");

exports.createCategory = async (req, res) => {
  const { name } = req.body;
  try {
    await Category.create({
      name,
    });
    return res.status(200).json({
      ok: true,
      status: 200,
      message: `Successfully created new category ${name}`,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      ok: false,
      status: 500,
      message: "Internal Server Error",
    });
  }
};

exports.updateCategory = async (req, res) => {
  const { category_name } = req.body;
  const { id } = req.params;
  try {
    const category = await Category.findOne({
      where: id,
    });

    const updated = await category.update({
      name: category_name,
    });
    await updated.save();

    return res.status(200).json({
      ok: true,
      status: 200,
      message: `Successfully update category ${category.name}`,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      ok: false,
      status: 500,
      message: "Internal Server Error",
    });
  }
};

exports.deleteCategory = async (req, res) => {
  const { id } = req.params;

  try {
    Category.beforeDestroy();

    await Category.destroy({
      where: { id },
      paranoid: true,
    });

    return res.status(200).json({
      ok: true,
      status: 200,
      message: "Category deleted successfully",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      ok: false,
      status: 500,
      message: "Internal Server Error",
    });
  }
};

exports.getAllCategories = async (req, res) => {
  try {
    const categories = await Category.findAll({
      attributes: ["id", "name"],
    });
    return res.status(200).json({
      ok: true,
      status: 200,
      categories,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      ok: false,
      status: 500,
      message: "Internal Server Error",
    });
  }
};
