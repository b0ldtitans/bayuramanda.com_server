const express = require("express");
const router = express.Router();
const authController = require("../controller/auth");
const authValidator = require("../validator/auth.js");

router.post("/", authController.loginHandler);

module.exports = router;
